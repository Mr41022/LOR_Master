class Utils {
  static setDataToLocalStorage() {
    return "Flutter App";
  }
}