// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';

// class studentHistorypage extends StatelessWidget {
//   const studentHistorypage({super.key, required String requestText});

//   @override
//   Widget build(BuildContext context) {
//     return child;
//   }
// }


// will Try to create a Dynamic Widget for the history page later