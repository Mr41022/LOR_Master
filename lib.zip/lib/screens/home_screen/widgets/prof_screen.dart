import 'package:flutter/material.dart';
import 'package:major_project/widgets/constants.dart';

Widget principalHome() {
  return ListView(
    children: [
      professorRequestAndHome(
        requestText: "Status",
      )
    ],
  );
}

Widget principalReq() {
  return ListView(
    children: [
      professorRequestAndHome(
        requestText: "Pending",
      )
    ],
  );
}
