import 'package:flutter/material.dart';
import 'package:major_project/widgets/constants.dart';

Widget studentHome() {
  return ListView(
    children: [
      studentHistoryAndHome(
        
          requestText: 'Recent Request\'s',
          onRequestTypeChanged: (index) {
            // setState(() {
            //   _selectedRequestType = index;
            // });
          }),
    ],
  );
}
